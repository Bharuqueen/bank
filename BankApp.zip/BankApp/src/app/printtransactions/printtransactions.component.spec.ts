import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinttransactionsComponent } from './printtransactions.component';

describe('PrinttransactionsComponent', () => {
  let component: PrinttransactionsComponent;
  let fixture: ComponentFixture<PrinttransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinttransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinttransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
