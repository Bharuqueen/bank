import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-printtransactions',
  templateUrl: './printtransactions.component.html',
  styleUrls: ['./printtransactions.component.css']
})
export class PrinttransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
