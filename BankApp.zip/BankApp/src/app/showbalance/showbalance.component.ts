import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
