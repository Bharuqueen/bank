import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrinttransactionsComponent } from './printtransactions/printtransactions.component';


const routes: Routes = [
  {
    path:'Home',
    component:HomeComponent
  },
  {
    path:'createaccount',
    component:CreateaccountComponent
  },
  {
  path:'',redirectTo:'Home',

    pathMatch:'full'
  },
  {
    path:'showbalance',
    component:ShowbalanceComponent
  },
  {
    path:'deposit',
    component:DepositComponent
  },
  {
    path:'withdraw',
    component:WithdrawComponent
  },
  {
    path:'fundtransfer',
    component:FundtransferComponent
  },
  {
    path:'printtransactions',
    component:PrinttransactionsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
